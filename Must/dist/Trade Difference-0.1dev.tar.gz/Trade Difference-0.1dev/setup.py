# -*- coding: utf-8 -*-

from distutils.core import setup

setup(
    name='Trade Difference',
    version='0.1dev',
    packages=['tradediff',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)